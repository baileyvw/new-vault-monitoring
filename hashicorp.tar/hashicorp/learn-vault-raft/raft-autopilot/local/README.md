# Integrated Storage Autopilot

These assets are provided to perform the tasks described in the [Integrated Storage Autopilot](https://learn.hashicorp.com/tutorials/vault/raft-autopilot) guide.

Refer to the tutorial for the detail steps. 

> This tutorial requires **Vault 1.7** or later.
