#!/bin/bash

# Setup vault_5 server
./cluster.sh setup vault_5

# Setup vault_6 server
./cluster.sh setup vault_6

# Setup vault_7 server
./cluster.sh setup vault_7