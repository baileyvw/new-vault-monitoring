# Integrated Storage Autopilot - Automatic Upgrade

These assets are provided to perform the tasks described in the [Automate Upgrades with Vault Enterprise](https://learn.hashicorp.com/tutorials/vault/raft-upgrade-automation) guide.

Refer to the tutorial for the detail steps.

> This tutorial requires **Vault Enterprise 1.11** or later.
