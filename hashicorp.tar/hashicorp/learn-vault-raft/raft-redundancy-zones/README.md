# Integrated Storage Autopilot - Redundancy Zones

These assets are provided to perform the tasks described in the [Fault Tolerance with Redundancy Zones](https://learn.hashicorp.com/tutorials/vault/raft-redundancy-zones) tutorial.

Refer to the tutorial for the detail steps.

> This tutorial requires **Vault Enterprise 1.11** or later.
