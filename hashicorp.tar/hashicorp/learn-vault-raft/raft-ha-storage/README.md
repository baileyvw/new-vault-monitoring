# Integrated Storage as an HA Storage

These assets are provided to perform the tasks described in the [Integrated Storage as an HA Storage](https://learn.hashicorp.com/vault/operations/raft-ha-storage) tutorial. Refer to the [learn](https://learn.hashicorp.com/vault) site for the detailed instruction.

> **NOTE:** This requires **Vault 1.5** or later.  Download the Vault 1.5 RC binary [here](https://releases.hashicorp.com/vault/). 
