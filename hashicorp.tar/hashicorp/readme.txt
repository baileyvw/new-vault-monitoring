kubectl exec vault-0 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                     Value
---                     -----
Seal Type               shamir
Initialized             true
Sealed                  false
Total Shares            1
Threshold               1
Version                 1.13.1
Build Date              2023-03-23T12:51:35Z
Storage Type            raft
Cluster Name            vault-cluster-3db8ec7f
Cluster ID              4d0ae564-7102-095b-ded6-474b6c7c5643
HA Enabled              true
HA Cluster              https://vault-0.vault-internal:8201
HA Mode                 active
Active Since            2023-06-07T11:23:54.325472386Z
Raft Committed Index    36
Raft Applied Index      36

kubectl exec vault-0 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                     Value
---                     -----
Seal Type               shamir
Initialized             true
Sealed                  false
Total Shares            1
Threshold               1
Version                 1.13.1
Build Date              2023-03-23T12:51:35Z
Storage Type            raft
Cluster Name            vault-cluster-3db8ec7f
Cluster ID              4d0ae564-7102-095b-ded6-474b6c7c5643
HA Enabled              true
HA Cluster              https://vault-0.vault-internal:8201
HA Mode                 active
Active Since            2023-06-07T11:23:54.325472386Z
Raft Committed Index    36

% kubectl exec vault-0 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                     Value
---                     -----
Seal Type               shamir
Initialized             true
Sealed                  false
Total Shares            1
Threshold               1
Version                 1.13.1
Build Date              2023-03-23T12:51:35Z
Storage Type            raft
Cluster Name            vault-cluster-3db8ec7f
Cluster ID              4d0ae564-7102-095b-ded6-474b6c7c5643
HA Enabled              true
HA Cluster              https://vault-0.vault-internal:8201
HA Mode                 active
Active Since            2023-06-07T11:23:54.325472386Z
Raft Committed Index    36
Raft Applied Index      36
12:24 vincebailey@enterprise /Users/vincebailey/hashicorp
% vi readme.txt
12:25 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-1 -- vault operator raft join http://vault-0.vault-internal:8200
Key       Value
---       -----
Joined    true
12:27 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-2 -- vault operator raft join http://vault-0.vault-internal:8200
Key       Value
---       -----
Joined    true
12:27 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-1 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       1
Threshold          1
Unseal Progress    0/1
Unseal Nonce       n/a
Version            1.13.1
Build Date         2023-03-23T12:51:35Z
Storage Type       raft
HA Enabled         true
12:28 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-2 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       1
Threshold          1
Unseal Progress    0/1
Unseal Nonce       n/a
Version            1.13.1
Build Date         2023-03-23T12:51:35Z
Storage Type       raft
HA Enabled         true
12:28 vincebailey@enterprise /Users/vincebailey/hashicorp
% jq -r ".root_token" cluster-keys.json
hvs.nQc0rY92zDd5Oht4Nv2e3QdP


% kubectl exec -ti vault-1 -- vault operator raft join http://vault-0.vault-internal:8200
Key       Value
---       -----
Joined    true
12:27 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-2 -- vault operator raft join http://vault-0.vault-internal:8200
Key       Value
---       -----
Joined    true
12:27 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-1 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       1
Threshold          1
Unseal Progress    0/1
Unseal Nonce       n/a
Version            1.13.1
Build Date         2023-03-23T12:51:35Z
Storage Type       raft
HA Enabled         true
12:28 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec -ti vault-2 -- vault operator unseal $VAULT_UNSEAL_KEY
Key                Value
---                -----
Seal Type          shamir
Initialized        true
Sealed             true
Total Shares       1
Threshold          1
Unseal Progress    0/1
Unseal Nonce       n/a
Version            1.13.1
Build Date         2023-03-23T12:51:35Z
Storage Type       raft
HA Enabled         true
12:28 vincebailey@enterprise /Users/vincebailey/hashicorp
% jq -r ".root_token" cluster-keys.json
hvs.nQc0rY92zDd5Oht4Nv2e3QdP
12:28 vincebailey@enterprise /Users/vincebailey/hashicorp
% 
12:29 vincebailey@enterprise /Users/vincebailey/hashicorp
% vi readme.txt
12:29 vincebailey@enterprise /Users/vincebailey/hashicorp
% kubectl exec --stdin=true --tty=true vault-0 -- /bin/sh
/ $ vault login
Token (will be hidden): 
Success! You are now authenticated. The token information displayed below
is already stored in the token helper. You do NOT need to run "vault login"
again. Future Vault requests will automatically use this token.

Key                  Value
---                  -----
token                hvs.nQc0rY92zDd5Oht4Nv2e3QdP
token_accessor       o7mp6iThidSb02hLdHzib164
token_duration       ∞
token_renewable      false
token_policies       ["root"]
identity_policies    []
policies             ["root"]
/ $ vault secrets enable -path=secret kv-v2
Success! Enabled the kv-v2 secrets engine at: secret/
/ $ vault kv put secret/webapp/config username="static-user" password="static-password"
====== Secret Path ======
secret/data/webapp/config

======= Metadata =======
Key                Value
---                -----
created_time       2023-06-07T11:31:47.251306845Z
custom_metadata    <nil>
deletion_time      n/a
destroyed          false
version            1
/ $ vault kv get secret/webapp/config
====== Secret Path ======
secret/data/webapp/config

======= Metadata =======
Key                Value
---                -----
created_time       2023-06-07T11:31:47.251306845Z
custom_metadata    <nil>
deletion_time      n/a
destroyed          false
version            1

====== Data ======
Key         Value
---         -----
password    static-password
username    static-user
/ $ exit

vagrant@ubuntu-xenial:~$ export VAULT_ADDR=http://:8200
vagrant@ubuntu-xenial:~$ vault status
Key                Value
---                -----
Seal Type          shamir
Initialized        false
Sealed             true
Total Shares       0
Threshold          0
Unseal Progress    0/0
Unseal Nonce       n/a
Version            1.13.2
Build Date         2023-04-25T13:02:50Z
Storage Type       consul
HA Enabled         true
vagrant@ubuntu-xenial:~$ vault operator init
Unseal Key 1: LXAYwPNR8iFGQWpwaXtG0XNcHH0aslkcV+bEIgHGV61n
Unseal Key 2: KppzbPT95waCQ/pPIVsNl1NU6rRtIj4r18Ab7RNZUBw+
Unseal Key 3: Jyg+Pqa3E65mJDgajDbewdsf+a+9jwZVG0EePUvIUi3k
Unseal Key 4: bIy5jxRz1Yz3SgfVLABr55COd6xNo6PEZ/ID+Fw/xVaz
Unseal Key 5: MJHlQcDr7UBzIP/z/SR1DS6QvEhAfx+/+DdgYDA1/nfj

Initial Root Token: hvs.1o1zR5vuARSHZQsxfK4GBD9g

Vault initialized with 5 key shares and a key threshold of 3. Please securely
distribute the key shares printed above. When the Vault is re-sealed,
restarted, or stopped, you must supply at least 3 of these keys to unseal it
before it can start servicing requests.

Vault does not store the generated root key. Without at least 3 keys to
reconstruct the root key, Vault will remain permanently sealed!
---------------------------------------------------------------------------

ault server -dev
==> Vault server configuration:

             Api Address: http://127.0.0.1:8200
                     Cgo: disabled
         Cluster Address: https://127.0.0.1:8201
   Environment Variables: GODEBUG, HOME, LANG, LC_CTYPE, LESSCLOSE, LESSOPEN, LOGNAME, LS_COLORS, MAIL, OLDPWD, PATH, PWD, SHELL, SHLVL, SUDO_COMMAND, SUDO_GID, SUDO_UID, SUDO_USER, TERM, USER, USERNAME, VAULT_ADDR, _
              Go Version: go1.20.4
              Listener 1: tcp (addr: "127.0.0.1:8200", cluster address: "127.0.0.1:8201", max_request_duration: "1m30s", max_request_size: "33554432", tls: "disabled")
               Log Level: 
                   Mlock: supported: true, enabled: false
           Recovery Mode: false
                 Storage: inmem
                 Version: Vault v1.13.3, built 2023-06-06T18:12:37Z
             Version Sha: 3bedf816cbf851656ae9e6bd65dd4a67a9ddff5e

==> Vault server started! Log data will stream in below:

2023-06-08T10:20:56.373Z [INFO]  proxy environment: http_proxy="" https_proxy="" no_proxy=""
2023-06-08T10:20:56.373Z [WARN]  no `api_addr` value specified in config or in VAULT_API_ADDR; falling back to detection if possible, but this value should be manually set
2023-06-08T10:20:56.374Z [INFO]  core: Initializing version history cache for core
2023-06-08T10:20:56.375Z [INFO]  core: security barrier not initialized
2023-06-08T10:20:56.375Z [INFO]  core: security barrier initialized: stored=1 shares=1 threshold=1
2023-06-08T10:20:56.375Z [INFO]  core: post-unseal setup starting
2023-06-08T10:20:56.387Z [INFO]  core: loaded wrapping token key
2023-06-08T10:20:56.387Z [INFO]  core: successfully setup plugin catalog: plugin-directory=""
2023-06-08T10:20:56.387Z [INFO]  core: no mounts; adding default mount table
2023-06-08T10:20:56.393Z [INFO]  core: successfully mounted: type=cubbyhole version="v1.13.3+builtin.vault" path=cubbyhole/ namespace="ID: root. Path: "
2023-06-08T10:20:56.394Z [INFO]  core: successfully mounted: type=system version="v1.13.3+builtin.vault" path=sys/ namespace="ID: root. Path: "
2023-06-08T10:20:56.395Z [INFO]  core: successfully mounted: type=identity version="v1.13.3+builtin.vault" path=identity/ namespace="ID: root. Path: "
2023-06-08T10:20:56.402Z [INFO]  core: successfully mounted: type=token version="v1.13.3+builtin.vault" path=token/ namespace="ID: root. Path: "
2023-06-08T10:20:56.402Z [INFO]  core: restoring leases
2023-06-08T10:20:56.402Z [INFO]  rollback: starting rollback manager
2023-06-08T10:20:56.403Z [INFO]  expiration: lease restore complete
2023-06-08T10:20:56.404Z [INFO]  identity: entities restored
2023-06-08T10:20:56.404Z [INFO]  identity: groups restored
2023-06-08T10:20:56.404Z [INFO]  core: Recorded vault version: vault version=1.13.3 upgrade time="2023-06-08 10:20:56.404180193 +0000 UTC" build date=2023-06-06T18:12:37Z
2023-06-08T10:20:56.581Z [INFO]  core: post-unseal setup complete
2023-06-08T10:20:56.581Z [INFO]  core: root token generated
2023-06-08T10:20:56.581Z [INFO]  core: pre-seal teardown starting
2023-06-08T10:20:56.581Z [INFO]  rollback: stopping rollback manager
2023-06-08T10:20:56.581Z [INFO]  core: pre-seal teardown complete
2023-06-08T10:20:56.581Z [INFO]  core.cluster-listener.tcp: starting listener: listener_address=127.0.0.1:8201
2023-06-08T10:20:56.581Z [INFO]  core.cluster-listener: serving cluster requests: cluster_listen_address=127.0.0.1:8201
2023-06-08T10:20:56.581Z [INFO]  core: post-unseal setup starting
2023-06-08T10:20:56.581Z [INFO]  core: loaded wrapping token key
2023-06-08T10:20:56.581Z [INFO]  core: successfully setup plugin catalog: plugin-directory=""
2023-06-08T10:20:56.582Z [INFO]  core: successfully mounted: type=system version="v1.13.3+builtin.vault" path=sys/ namespace="ID: root. Path: "
2023-06-08T10:20:56.582Z [INFO]  core: successfully mounted: type=identity version="v1.13.3+builtin.vault" path=identity/ namespace="ID: root. Path: "
2023-06-08T10:20:56.582Z [INFO]  core: successfully mounted: type=cubbyhole version="v1.13.3+builtin.vault" path=cubbyhole/ namespace="ID: root. Path: "
2023-06-08T10:20:56.582Z [INFO]  core: successfully mounted: type=token version="v1.13.3+builtin.vault" path=token/ namespace="ID: root. Path: "
2023-06-08T10:20:56.583Z [INFO]  core: restoring leases
2023-06-08T10:20:56.583Z [INFO]  expiration: lease restore complete
2023-06-08T10:20:56.583Z [INFO]  rollback: starting rollback manager
2023-06-08T10:20:56.583Z [INFO]  identity: entities restored
2023-06-08T10:20:56.583Z [INFO]  identity: groups restored
2023-06-08T10:20:56.583Z [INFO]  core: post-unseal setup complete
2023-06-08T10:20:56.583Z [INFO]  core: vault is unsealed
2023-06-08T10:20:56.585Z [INFO]  core: successful mount: namespace="" path=secret/ type=kv version=""
WARNING! dev mode is enabled! In this mode, Vault runs entirely in-memory
and starts unsealed with a single unseal key. The root token is already
authenticated to the CLI, so you can immediately begin using Vault.

You may need to set the following environment variables:

    $ export VAULT_ADDR='http://127.0.0.1:8200'

The unseal key and root token are displayed below in case you want to
seal/unseal the Vault or re-authenticate.

Unseal Key: jHj9V3kzytDStLNyACH1BoO5B4lu2vQlG6YINENXQDI=
Root Token: hvs.fYNc8b9LlxeypYeVWziYGakQ

Development mode should NOT be used in production installations!


root@ubuntu-xenial:~# export VAULT_ADDR=http://:8200
root@ubuntu-xenial:~# vault status
Key                Value
---                -----
Seal Type          shamir
Initialized        false
Sealed             true
Total Shares       0
Threshold          0
Unseal Progress    0/0
Unseal Nonce       n/a
Version            1.13.3
Build Date         2023-06-06T18:12:37Z
Storage Type       consul
HA Enabled         true
root@ubuntu-xenial:~# vault operator init
Unseal Key 1: 16UdntIOU/quOdPlCySTqSI5+9ykB040Eh3hGPQuEMjq
Unseal Key 2: n62DvErx/xqr7vNmJIkdTZ/kvtvHdIWbGp1RHlK3mAso
Unseal Key 3: saMIDUQE0ANiBR5BwpHLKzzTnTKX8iXRoVIQTuhPA+vJ
Unseal Key 4: jJV/W7Cij0QwHXfQy25Sh/rFS6edG8AN5kH4fCuCkqRK
Unseal Key 5: foNBbvd6nKRloZu20OvPEh5JRANbT8iA1fUXsSvy43y8

Initial Root Token: hvs.c8w6XOAxhrtGobp8KLXW74BN

Vault initialized with 5 key shares and a key threshold of 3. Please securely
distribute the key shares printed above. When the Vault is re-sealed,
restarted, or stopped, you must supply at least 3 of these keys to unseal it
before it can start servicing requests.

Vault does not store the generated root key. Without at least 3 keys to
reconstruct the root key, Vault will remain permanently sealed!

It is possible to generate new unseal keys, provided you have a quorum of
existing unseal keys shares. See "vault operator rekey" for more information.
root@ubuntu-xenial:~# hvs.CAESIIuWMn3ND_QZ-PJwpkgvGtqJ44kIEqBbKDtsNC4TAmsuGh4KHGh2cy45eGJiNTlsUVFhdFRJb1A4aEFFY2tsNlU
